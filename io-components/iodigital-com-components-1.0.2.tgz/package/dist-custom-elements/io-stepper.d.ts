import type { Components, JSX } from "../dist/types/components";

interface IoStepper extends Components.IoStepper, HTMLElement {}
export const IoStepper: {
    prototype: IoStepper;
    new (): IoStepper;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
