import type { Components, JSX } from "../dist/types/components";

interface IoFormField extends Components.IoFormField, HTMLElement {}
export const IoFormField: {
    prototype: IoFormField;
    new (): IoFormField;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
