import type { Components, JSX } from "../dist/types/components";

interface IoDivider extends Components.IoDivider, HTMLElement {}
export const IoDivider: {
    prototype: IoDivider;
    new (): IoDivider;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
