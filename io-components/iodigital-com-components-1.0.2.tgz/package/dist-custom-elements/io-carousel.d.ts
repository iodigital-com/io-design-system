import type { Components, JSX } from "../dist/types/components";

interface IoCarousel extends Components.IoCarousel, HTMLElement {}
export const IoCarousel: {
    prototype: IoCarousel;
    new (): IoCarousel;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
