import type { Components, JSX } from "../dist/types/components";

interface IoSpinner extends Components.IoSpinner, HTMLElement {}
export const IoSpinner: {
    prototype: IoSpinner;
    new (): IoSpinner;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
