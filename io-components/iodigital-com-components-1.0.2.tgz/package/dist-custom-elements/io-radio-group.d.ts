import type { Components, JSX } from "../dist/types/components";

interface IoRadioGroup extends Components.IoRadioGroup, HTMLElement {}
export const IoRadioGroup: {
    prototype: IoRadioGroup;
    new (): IoRadioGroup;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
