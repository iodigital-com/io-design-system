import type { Components, JSX } from "../dist/types/components";

interface IoCheckbox extends Components.IoCheckbox, HTMLElement {}
export const IoCheckbox: {
    prototype: IoCheckbox;
    new (): IoCheckbox;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
