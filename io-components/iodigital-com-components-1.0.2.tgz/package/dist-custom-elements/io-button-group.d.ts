import type { Components, JSX } from "../dist/types/components";

interface IoButtonGroup extends Components.IoButtonGroup, HTMLElement {}
export const IoButtonGroup: {
    prototype: IoButtonGroup;
    new (): IoButtonGroup;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
