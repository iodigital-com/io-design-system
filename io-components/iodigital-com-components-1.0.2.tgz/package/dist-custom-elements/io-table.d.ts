import type { Components, JSX } from "../dist/types/components";

interface IoTable extends Components.IoTable, HTMLElement {}
export const IoTable: {
    prototype: IoTable;
    new (): IoTable;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
