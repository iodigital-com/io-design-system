import type { Components, JSX } from "../dist/types/components";

interface IoTableHead extends Components.IoTableHead, HTMLElement {}
export const IoTableHead: {
    prototype: IoTableHead;
    new (): IoTableHead;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
