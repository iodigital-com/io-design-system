import type { Components, JSX } from "../dist/types/components";

interface IoCheckboxGroup extends Components.IoCheckboxGroup, HTMLElement {}
export const IoCheckboxGroup: {
    prototype: IoCheckboxGroup;
    new (): IoCheckboxGroup;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
