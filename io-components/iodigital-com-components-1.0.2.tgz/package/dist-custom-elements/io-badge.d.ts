import type { Components, JSX } from "../dist/types/components";

interface IoBadge extends Components.IoBadge, HTMLElement {}
export const IoBadge: {
    prototype: IoBadge;
    new (): IoBadge;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
