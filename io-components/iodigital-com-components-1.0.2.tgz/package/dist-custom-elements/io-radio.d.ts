import type { Components, JSX } from "../dist/types/components";

interface IoRadio extends Components.IoRadio, HTMLElement {}
export const IoRadio: {
    prototype: IoRadio;
    new (): IoRadio;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
