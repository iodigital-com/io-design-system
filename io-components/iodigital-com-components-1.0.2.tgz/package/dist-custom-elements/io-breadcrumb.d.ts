import type { Components, JSX } from "../dist/types/components";

interface IoBreadcrumb extends Components.IoBreadcrumb, HTMLElement {}
export const IoBreadcrumb: {
    prototype: IoBreadcrumb;
    new (): IoBreadcrumb;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
