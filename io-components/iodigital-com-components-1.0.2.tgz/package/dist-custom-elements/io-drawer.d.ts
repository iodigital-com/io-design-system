import type { Components, JSX } from "../dist/types/components";

interface IoDrawer extends Components.IoDrawer, HTMLElement {}
export const IoDrawer: {
    prototype: IoDrawer;
    new (): IoDrawer;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
