import type { Components, JSX } from "../dist/types/components";

interface IoHeading extends Components.IoHeading, HTMLElement {}
export const IoHeading: {
    prototype: IoHeading;
    new (): IoHeading;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
