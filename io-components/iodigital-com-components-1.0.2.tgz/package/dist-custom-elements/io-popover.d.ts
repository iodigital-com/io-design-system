import type { Components, JSX } from "../dist/types/components";

interface IoPopover extends Components.IoPopover, HTMLElement {}
export const IoPopover: {
    prototype: IoPopover;
    new (): IoPopover;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
