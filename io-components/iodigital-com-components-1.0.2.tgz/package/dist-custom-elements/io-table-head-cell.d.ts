import type { Components, JSX } from "../dist/types/components";

interface IoTableHeadCell extends Components.IoTableHeadCell, HTMLElement {}
export const IoTableHeadCell: {
    prototype: IoTableHeadCell;
    new (): IoTableHeadCell;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
