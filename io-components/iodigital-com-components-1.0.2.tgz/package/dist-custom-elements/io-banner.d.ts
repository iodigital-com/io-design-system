import type { Components, JSX } from "../dist/types/components";

interface IoBanner extends Components.IoBanner, HTMLElement {}
export const IoBanner: {
    prototype: IoBanner;
    new (): IoBanner;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
