import type { Components, JSX } from "../dist/types/components";

interface IoTag extends Components.IoTag, HTMLElement {}
export const IoTag: {
    prototype: IoTag;
    new (): IoTag;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
