import type { Components, JSX } from "../dist/types/components";

interface IoProgress extends Components.IoProgress, HTMLElement {}
export const IoProgress: {
    prototype: IoProgress;
    new (): IoProgress;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
