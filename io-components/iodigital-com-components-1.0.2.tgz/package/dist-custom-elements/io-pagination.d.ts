import type { Components, JSX } from "../dist/types/components";

interface IoPagination extends Components.IoPagination, HTMLElement {}
export const IoPagination: {
    prototype: IoPagination;
    new (): IoPagination;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
