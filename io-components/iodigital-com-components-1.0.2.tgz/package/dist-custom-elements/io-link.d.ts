import type { Components, JSX } from "../dist/types/components";

interface IoLink extends Components.IoLink, HTMLElement {}
export const IoLink: {
    prototype: IoLink;
    new (): IoLink;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
