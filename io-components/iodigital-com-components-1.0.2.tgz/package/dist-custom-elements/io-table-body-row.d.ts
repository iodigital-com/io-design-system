import type { Components, JSX } from "../dist/types/components";

interface IoTableBodyRow extends Components.IoTableBodyRow, HTMLElement {}
export const IoTableBodyRow: {
    prototype: IoTableBodyRow;
    new (): IoTableBodyRow;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
