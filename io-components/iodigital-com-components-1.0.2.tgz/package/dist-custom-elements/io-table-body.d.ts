import type { Components, JSX } from "../dist/types/components";

interface IoTableBody extends Components.IoTableBody, HTMLElement {}
export const IoTableBody: {
    prototype: IoTableBody;
    new (): IoTableBody;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
