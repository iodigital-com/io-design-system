import type { Components, JSX } from "../dist/types/components";

interface IoBreadcrumbItem extends Components.IoBreadcrumbItem, HTMLElement {}
export const IoBreadcrumbItem: {
    prototype: IoBreadcrumbItem;
    new (): IoBreadcrumbItem;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
