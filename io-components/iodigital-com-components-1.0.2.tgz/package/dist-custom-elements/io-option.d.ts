import type { Components, JSX } from "../dist/types/components";

interface IoOption extends Components.IoOption, HTMLElement {}
export const IoOption: {
    prototype: IoOption;
    new (): IoOption;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
