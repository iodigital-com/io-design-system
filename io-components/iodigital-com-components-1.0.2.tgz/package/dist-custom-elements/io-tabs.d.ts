import type { Components, JSX } from "../dist/types/components";

interface IoTabs extends Components.IoTabs, HTMLElement {}
export const IoTabs: {
    prototype: IoTabs;
    new (): IoTabs;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
