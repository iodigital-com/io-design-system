import type { Components, JSX } from "../dist/types/components";

interface IoInput extends Components.IoInput, HTMLElement {}
export const IoInput: {
    prototype: IoInput;
    new (): IoInput;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
