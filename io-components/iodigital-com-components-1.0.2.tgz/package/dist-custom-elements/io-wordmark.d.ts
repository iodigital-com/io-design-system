import type { Components, JSX } from "../dist/types/components";

interface IoWordmark extends Components.IoWordmark, HTMLElement {}
export const IoWordmark: {
    prototype: IoWordmark;
    new (): IoWordmark;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
