import type { Components, JSX } from "../dist/types/components";

interface IoTableHeadRow extends Components.IoTableHeadRow, HTMLElement {}
export const IoTableHeadRow: {
    prototype: IoTableHeadRow;
    new (): IoTableHeadRow;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
