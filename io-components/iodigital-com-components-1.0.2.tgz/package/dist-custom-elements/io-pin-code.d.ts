import type { Components, JSX } from "../dist/types/components";

interface IoPinCode extends Components.IoPinCode, HTMLElement {}
export const IoPinCode: {
    prototype: IoPinCode;
    new (): IoPinCode;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
