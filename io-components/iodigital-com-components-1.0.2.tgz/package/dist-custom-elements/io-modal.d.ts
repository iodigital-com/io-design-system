import type { Components, JSX } from "../dist/types/components";

interface IoModal extends Components.IoModal, HTMLElement {}
export const IoModal: {
    prototype: IoModal;
    new (): IoModal;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
