import type { Components, JSX } from "../dist/types/components";

interface IoTextarea extends Components.IoTextarea, HTMLElement {}
export const IoTextarea: {
    prototype: IoTextarea;
    new (): IoTextarea;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
