import type { Components, JSX } from "../dist/types/components";

interface IoOptgroup extends Components.IoOptgroup, HTMLElement {}
export const IoOptgroup: {
    prototype: IoOptgroup;
    new (): IoOptgroup;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
