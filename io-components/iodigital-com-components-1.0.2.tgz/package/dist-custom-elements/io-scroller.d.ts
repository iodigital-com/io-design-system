import type { Components, JSX } from "../dist/types/components";

interface IoScroller extends Components.IoScroller, HTMLElement {}
export const IoScroller: {
    prototype: IoScroller;
    new (): IoScroller;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
