import type { Components, JSX } from "../dist/types/components";

interface IoSwitch extends Components.IoSwitch, HTMLElement {}
export const IoSwitch: {
    prototype: IoSwitch;
    new (): IoSwitch;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
