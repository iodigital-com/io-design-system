import type { Components, JSX } from "../dist/types/components";

interface IoButton extends Components.IoButton, HTMLElement {}
export const IoButton: {
    prototype: IoButton;
    new (): IoButton;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
