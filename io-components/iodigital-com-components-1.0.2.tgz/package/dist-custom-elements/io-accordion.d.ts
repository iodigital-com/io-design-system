import type { Components, JSX } from "../dist/types/components";

interface IoAccordion extends Components.IoAccordion, HTMLElement {}
export const IoAccordion: {
    prototype: IoAccordion;
    new (): IoAccordion;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
