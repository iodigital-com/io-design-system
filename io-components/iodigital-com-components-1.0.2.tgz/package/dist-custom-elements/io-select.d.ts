import type { Components, JSX } from "../dist/types/components";

interface IoSelect extends Components.IoSelect, HTMLElement {}
export const IoSelect: {
    prototype: IoSelect;
    new (): IoSelect;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
