import type { Components, JSX } from "../dist/types/components";

interface IoTabsBar extends Components.IoTabsBar, HTMLElement {}
export const IoTabsBar: {
    prototype: IoTabsBar;
    new (): IoTabsBar;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
