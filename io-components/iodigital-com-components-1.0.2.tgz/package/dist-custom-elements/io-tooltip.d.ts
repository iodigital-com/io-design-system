import type { Components, JSX } from "../dist/types/components";

interface IoTooltip extends Components.IoTooltip, HTMLElement {}
export const IoTooltip: {
    prototype: IoTooltip;
    new (): IoTooltip;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
