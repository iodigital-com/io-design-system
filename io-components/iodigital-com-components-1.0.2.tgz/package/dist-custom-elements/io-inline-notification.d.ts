import type { Components, JSX } from "../dist/types/components";

interface IoInlineNotification extends Components.IoInlineNotification, HTMLElement {}
export const IoInlineNotification: {
    prototype: IoInlineNotification;
    new (): IoInlineNotification;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
