import type { Components, JSX } from "../dist/types/components";

interface IoStep extends Components.IoStep, HTMLElement {}
export const IoStep: {
    prototype: IoStep;
    new (): IoStep;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
