import type { Components, JSX } from "../dist/types/components";

interface IoText extends Components.IoText, HTMLElement {}
export const IoText: {
    prototype: IoText;
    new (): IoText;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
