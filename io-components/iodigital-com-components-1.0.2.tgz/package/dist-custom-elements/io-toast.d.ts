import type { Components, JSX } from "../dist/types/components";

interface IoToast extends Components.IoToast, HTMLElement {}
export const IoToast: {
    prototype: IoToast;
    new (): IoToast;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
