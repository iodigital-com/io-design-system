import type { Components, JSX } from "../dist/types/components";

interface IoAvatar extends Components.IoAvatar, HTMLElement {}
export const IoAvatar: {
    prototype: IoAvatar;
    new (): IoAvatar;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
