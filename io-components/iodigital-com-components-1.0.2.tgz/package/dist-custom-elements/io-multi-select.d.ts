import type { Components, JSX } from "../dist/types/components";

interface IoMultiSelect extends Components.IoMultiSelect, HTMLElement {}
export const IoMultiSelect: {
    prototype: IoMultiSelect;
    new (): IoMultiSelect;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
