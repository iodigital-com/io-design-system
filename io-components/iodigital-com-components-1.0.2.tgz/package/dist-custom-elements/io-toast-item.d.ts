import type { Components, JSX } from "../dist/types/components";

interface IoToastItem extends Components.IoToastItem, HTMLElement {}
export const IoToastItem: {
    prototype: IoToastItem;
    new (): IoToastItem;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
