import type { Components, JSX } from "../dist/types/components";

interface IoTableBodyCell extends Components.IoTableBodyCell, HTMLElement {}
export const IoTableBodyCell: {
    prototype: IoTableBodyCell;
    new (): IoTableBodyCell;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
